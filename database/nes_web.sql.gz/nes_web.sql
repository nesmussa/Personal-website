-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 14, 2025 at 04:09 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nes_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `No` int(11) NOT NULL,
  `about_paragraph` text NOT NULL,
  `Posted` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `edu`
--

CREATE TABLE `edu` (
  `No` int(11) NOT NULL,
  `edu_p` varchar(5000) NOT NULL,
  `Posted` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `No` int(11) NOT NULL,
  `Date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `rating` int(11) DEFAULT NULL,
  `Comment` varchar(5000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`No`, `Date`, `Name`, `Email`, `rating`, `Comment`) VALUES
(1, '2023-06-18 00:17:54', 'Nesrlah Mussa Ahimed', 'emileofnm@gmail.com', 3, ''),
(2, '2023-06-18 00:18:33', 'Nesrlah Mussa Ahimed', 'emileofnm@gmail.com', 3, ''),
(3, '2023-06-18 00:18:59', 'Nesrlah Mussa Ahimed', 'emileofnm@gmail.com', 1, 'sfdfsfs'),
(4, '2023-06-18 00:23:37', 'nes.mussa', 'emileofnm@gmail.com', 4, 'assdsd'),
(5, '2023-06-18 00:25:20', 'nes.mussa', 'emileofnm@gmail.com', 4, 'assdsd'),
(6, '2023-06-18 00:25:35', 'nes.mussa', 'emileofnm@gmail.com', 5, 'asdas'),
(7, '2023-06-18 10:29:02', 'Yesmin', 'emailofym@gmail.com', 4, 'በጣም ጥሩ ነበር ግን እስፔሊንግህ ገደል ገብቷል'),
(8, '2023-06-19 18:42:36', 'hilina woldu', 'wolduhilina@gmail.com', 5, 'betam arif new......gn ene kante bzu etebkalew kezim belay yemesrat akmu endalek amnalew ena yalekn emk hayl awtetek tetekem TECHLALEK BROOO ');

-- --------------------------------------------------------

--
-- Table structure for table `fov`
--

CREATE TABLE `fov` (
  `No` int(11) NOT NULL,
  `fov_p` varchar(5000) NOT NULL,
  `Posted` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fuc`
--

CREATE TABLE `fuc` (
  `No` int(11) NOT NULL,
  `fuc_p` int(11) NOT NULL,
  `Posted` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fuc`
--

INSERT INTO `fuc` (`No`, `fuc_p`, `Posted`) VALUES
(1, 123, '2023-06-20 15:02:00');

-- --------------------------------------------------------

--
-- Table structure for table `verifi`
--

CREATE TABLE `verifi` (
  `No` int(11) NOT NULL,
  `uname` varchar(15) NOT NULL,
  `pass` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `verifi`
--

INSERT INTO `verifi` (`No`, `uname`, `pass`) VALUES
(1, 'username', 'password');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`No`);

--
-- Indexes for table `edu`
--
ALTER TABLE `edu`
  ADD PRIMARY KEY (`No`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`No`);

--
-- Indexes for table `fov`
--
ALTER TABLE `fov`
  ADD PRIMARY KEY (`No`);

--
-- Indexes for table `fuc`
--
ALTER TABLE `fuc`
  ADD PRIMARY KEY (`No`);

--
-- Indexes for table `verifi`
--
ALTER TABLE `verifi`
  ADD PRIMARY KEY (`No`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about`
--
ALTER TABLE `about`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `edu`
--
ALTER TABLE `edu`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `fov`
--
ALTER TABLE `fov`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fuc`
--
ALTER TABLE `fuc`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `verifi`
--
ALTER TABLE `verifi`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
